export const Users = [
  { userType: "super-admin" },
  { userType: "admin" },
  { userType: "operations-manager" },
  { userType: "project-manager" },
  { userType: "team-lead" },
  { userType: "team-member" },
];
