## Intro to this project

This project, named "Projectorate" is being made as Muneeb ur rehman's final year project
