import React from "react";

export default function Board() {
  return <div className="mx-4 h-[20rem] w-72 bg-gray-900">hello worl</div>;
}
