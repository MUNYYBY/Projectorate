"use strict";
(() => {
var exports = {};
exports.id = 2741;
exports.ids = [2741,6366,9958];
exports.modules = {

/***/ 591:
/***/ (() => {

/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/temp.347a1be7.png","height":197,"width":256,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAGBAMAAAAMK8LIAAAAKlBMVEX////+/v79/f78/f309vj09fjz9Pfj5+7i5u7V2+bU2ubM0+HIz9/Hz968cpVmAAAAJUlEQVR42mMQYGBgZGAMbxFgEDi9l5FBQHMxkMuaIMAgIMDICABA9AQMAN2h8gAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":6});

/***/ }),

/***/ 3385:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6197);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(598);
/* harmony import */ var _context_notificationContext__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5329);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _client_requests__WEBPACK_IMPORTED_MODULE_5__]);
([framer_motion__WEBPACK_IMPORTED_MODULE_2__, _client_requests__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);










function AddEmployee(props) {
    const { 0: employeePayload , 1: setEmployeePayload  } = useState({
        firstName: "",
        lastName: "",
        email: "",
        password: "",
        phoneNumber: "",
        dateOfBirth: "",
        expertise: "",
        designation: "",
        dateOfJoining: "",
        yearsOfExperience: ""
    });
    const { 0: isSubmitClicked , 1: setIsSubmitClicked  } = useState(false);
    const { notifications , setNotifications  } = useNotificationsHandler();
    const handleEmployeeSubmission = async (e)=>{
        e.preventDefault();
        // console.log(employeePayload);
        if (employeePayload.email != "" && employeePayload.password) {
            let res = createEmployee(employeePayload);
            console.log(res);
            if (res) {
                setNotifications({
                    placement: "bottomRight",
                    message: "New Employee Added to the Projectorate",
                    description: "",
                    type: "sucess"
                });
                setIsSubmitClicked(true);
                setTimeout(()=>{
                    props.setAddEmployees(false);
                    props.setCheckForNewEmployees(true);
                }, 2000);
            }
        }
    };
    // useEffect(() => {
    //   console.log(employeePayload);
    // }, [employeePayload]);
    return /*#__PURE__*/ _jsxs("div", {
        className: "Add-Employees w-screen h-screen absolute top-0 z-50",
        children: [
            /*#__PURE__*/ _jsx("div", {
                className: "w-full h-full flex flex-col justify-center items-center absolute top-0 z-20",
                children: /*#__PURE__*/ _jsx(AnimatePresence, {
                    children: /*#__PURE__*/ _jsx(motion.div, {
                        initial: {
                            scale: 0
                        },
                        animate: {
                            scale: 1
                        },
                        transition: {
                            duration: 0.3
                        },
                        exit: {
                            opacity: 0
                        },
                        children: /*#__PURE__*/ _jsxs("div", {
                            className: "bg-gray-300 p-6 m-2 min-w-[20rem] max-w-[50rem] rounded-md ",
                            children: [
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex flex-col justify-center items-center mb-4",
                                    children: [
                                        /*#__PURE__*/ _jsx("h1", {
                                            className: "font-demo text-3xl text-gray-900",
                                            children: "Add Employee"
                                        }),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "text-gray-900 text-center",
                                            children: "Add a new member your to your company to expand your company portfolio..."
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsx("form", {
                                    onSubmit: handleEmployeeSubmission,
                                    children: /*#__PURE__*/ _jsxs("div", {
                                        className: "Input-stack w-full",
                                        children: [
                                            /*#__PURE__*/ _jsxs(Row, {
                                                gutter: [
                                                    8,
                                                    8
                                                ],
                                                children: [
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "employee_first_name",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Employee First Name >",
                                                                type: "text",
                                                                name: "employee_first_name",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        firstName: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "employee_last_name",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Employee Last Name >",
                                                                type: "text",
                                                                name: "employee_last_name",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        lastName: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "employee_email",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Employee Email >",
                                                                type: "email",
                                                                name: "employee_email",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        email: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "employee_password",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Employee Password >",
                                                                type: "password",
                                                                name: "employee_password",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        password: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "phone_number ",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Phone Number >",
                                                                type: "text",
                                                                name: "phone_number",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        phoneNumber: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "date_of_birth",
                                                            children: /*#__PURE__*/ _jsx(DatePicker, {
                                                                className: "text-gray-50 bg-gray-900 h-12 rounded-md w-full p-4 border-2 border-black",
                                                                placeholder: "< Date of Birth >",
                                                                onChange: (date)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        dateOfBirth: date.$d
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "expertise",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Expertise >",
                                                                type: "text",
                                                                name: "expertise",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        expertise: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "designation",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Designation >",
                                                                type: "text",
                                                                name: "designation",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        designation: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "date_of_joining",
                                                            children: /*#__PURE__*/ _jsx(DatePicker, {
                                                                className: "text-gray-50 bg-gray-900 h-12 rounded-md w-full p-4 border-2 border-black",
                                                                placeholder: "< Date of Joining >",
                                                                onChange: (date)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        dateOfJoining: date.$d
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "years_of_experience",
                                                            children: /*#__PURE__*/ _jsx("input", {
                                                                placeholder: "< Years of Experience >",
                                                                type: "number",
                                                                name: "years_of_experience",
                                                                className: "bg-gray-900 h-12 rounded-md w-full p-4 focus:outline-0 border-2 border-black",
                                                                onChange: (e)=>setEmployeePayload({
                                                                        ...employeePayload,
                                                                        yearsOfExperience: e.target.value
                                                                    })
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ _jsx(Col, {
                                                        xs: 24,
                                                        lg: 12,
                                                        children: /*#__PURE__*/ _jsx("div", {
                                                            className: "upload-image",
                                                            children: /*#__PURE__*/ _jsx(Upload, {
                                                                accept: "image/png, image/jpeg",
                                                                children: /*#__PURE__*/ _jsx(Button, {
                                                                    icon: /*#__PURE__*/ _jsx(UploadOutlined, {}),
                                                                    className: "bg-gray-700 h-10 text-gray-50 d-flex flex-row justify-items-center items-center",
                                                                    children: "Upload"
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ _jsxs("div", {
                                                className: "flex flex-col justify-center items-center mt-6",
                                                children: [
                                                    /*#__PURE__*/ _jsx("p", {
                                                        className: "text-sm text-gray-900 text-center",
                                                        children: "Before clicking Add employee please verify the details that you have entered!"
                                                    }),
                                                    /*#__PURE__*/ _jsx("button", {
                                                        className: !isSubmitClicked ? "bg-primary px-4 py-3 rounded-lg mt-1" : "bg-primary px-4 py-3 rounded-lg mt-1 opacity-60",
                                                        disabled: isSubmitClicked,
                                                        children: "ADD EMPLOYEE"
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ _jsx(AnimatePresence, {
                children: /*#__PURE__*/ _jsx(motion.div, {
                    initial: {
                        opacity: 0
                    },
                    animate: {
                        opacity: 1
                    },
                    transition: {
                        duration: 0.2
                    },
                    exit: {
                        opacity: 0
                    },
                    children: /*#__PURE__*/ _jsx("div", {
                        className: "w-screen h-screen absolute top-0 bg-gray-900 opacity-80 z-10"
                    })
                })
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AddEmployee)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__]);
_client_requests__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const { Option  } = antd__WEBPACK_IMPORTED_MODULE_1__.Select;
const formItemLayout = {
    labelCol: {
        xs: {
            span: 7
        },
        sm: {
            span: 5
        }
    },
    wrapperCol: {
        xs: {
            span: 22
        },
        sm: {
            span: 18
        }
    }
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 24,
            offset: 0
        },
        sm: {
            span: 8,
            offset: 0
        }
    }
};
function AddEmployee(props) {
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    const { 0: designations , 1: setDesignations  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: roles , 1: setRoles  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
    const handleEmployeeSubmission = async (payload)=>{
        setLoading(true);
        let res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .createEmployee */ .r8)(payload);
        console.log(res);
        if (res?.error) {
            antd__WEBPACK_IMPORTED_MODULE_1__.message.error("Employee submission failed!");
            setLoading(false);
        } else {
            antd__WEBPACK_IMPORTED_MODULE_1__.message.success("Employee added successfully!");
            form.resetFields();
            props.setAddEmployee(false);
        }
    };
    const onFinish = (values)=>{
        // console.log("Received values of form: ", values);
        handleEmployeeSubmission({
            ...values,
            userId: session.user.id
        });
    };
    //get all the designations in the db
    const getAllDesignations = async ()=>{
        const designationsResponse = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getDesignations */ .qI)();
        setDesignations(designationsResponse.data);
    };
    //get all the roles in the db
    const getAllRoles = async ()=>{
        const rolesResponse = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getRoles */ .F3)();
        const data = rolesResponse.data;
        data.splice(0, 1); // remove super-admin from roles
        setRoles(data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getAllDesignations();
        getAllRoles();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (designations && roles) {
            setLoading(false);
        }
    // console.log(designations);
    // console.log(roles);
    }, [
        designations,
        roles
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container flex w-full flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-12 text-base flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-xl font-bold ",
                            children: " Add New Employee"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Kindly fill out the following form carefully!"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Form, {
                        ...formItemLayout,
                        form: form,
                        name: "register",
                        onFinish: onFinish,
                        style: {
                            width: "100%"
                        },
                        scrollToFirstError: true,
                        disabled: loading,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Row, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Col, {
                                        xs: {
                                            span: 22,
                                            offset: 1
                                        },
                                        lg: {
                                            span: 11,
                                            offset: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "firstName",
                                                label: "First Name",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input employee's first name"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "First name must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 20,
                                                        message: "First name must be maximum of 20 characters"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "lastName",
                                                label: "Last Name",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input employee's last name"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "last name must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 20,
                                                        message: "last name must be maximum of 20 characters"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "email",
                                                label: "E-mail",
                                                rules: [
                                                    {
                                                        type: "email",
                                                        message: "The input is not valid E-mail!"
                                                    },
                                                    {
                                                        required: true,
                                                        message: "Please input your E-mail!"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "address",
                                                label: "Address",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please add employee address"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "Address must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 40,
                                                        message: "Address must be maximum of 40 characters"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "phoneNumber",
                                                label: "Phone Number",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input your phone number!"
                                                    },
                                                    {
                                                        max: 11,
                                                        message: "Number should be 11 digits long"
                                                    },
                                                    {
                                                        min: 11,
                                                        message: "Number should be 11 digits long"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                    style: {
                                                        width: "100%"
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "dateOfBirth",
                                                label: "Date of Birth",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input a date of birth!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {
                                                    className: "w-full",
                                                    disabledDate: (current)=>{
                                                        return moment__WEBPACK_IMPORTED_MODULE_4___default()().add(-18, "years") <= current;
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "dateOfJoining",
                                                label: "Date of Join",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input a date of joining for employee!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {
                                                    className: "w-full",
                                                    disabledDate: (current)=>{
                                                        return moment__WEBPACK_IMPORTED_MODULE_4___default()().add(-1, "years") >= current || moment__WEBPACK_IMPORTED_MODULE_4___default()().add(4, "months") <= current;
                                                    }
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Col, {
                                        xs: {
                                            span: 22,
                                            offset: 1
                                        },
                                        lg: {
                                            span: 11,
                                            offset: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "yearsOfExperience",
                                                label: "Years of experince",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please add years of experience!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.InputNumber, {
                                                    className: "w-full",
                                                    type: "number"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "gender",
                                                label: "Gender",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please a gender!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select gender",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: "male",
                                                            children: "Male"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: "female",
                                                            children: "Female"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "expertise",
                                                label: "Expertise",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input Expertise! E.g Front-end Developer"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    },
                                                    {
                                                        max: 30,
                                                        message: "Maximum length of expertise can be 30 characters long!"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "Minimum length of expertise can be 4 characters long!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "designation",
                                                label: "Designation",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please select a designation!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select your A designation for employee",
                                                    children: designations?.map((designation)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: designation.id,
                                                            children: designation.title
                                                        }, designation.id);
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "role",
                                                label: "Role",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please select a role!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select your A role for employee",
                                                    children: roles?.map((role)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: role.id,
                                                            children: role.title
                                                        }, role.id);
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "password",
                                                label: "Password",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input your password!"
                                                    },
                                                    {
                                                        min: 8,
                                                        message: "Password must be 8 characters long!"
                                                    }, 
                                                ],
                                                hasFeedback: true,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "confirm",
                                                label: "Confirm Password",
                                                dependencies: [
                                                    "password"
                                                ],
                                                hasFeedback: true,
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please confirm your password!"
                                                    },
                                                    ({ getFieldValue  })=>({
                                                            validator (_, value) {
                                                                if (!value || getFieldValue("password") === value) {
                                                                    return Promise.resolve();
                                                                }
                                                                return Promise.reject(new Error("The two passwords that you entered do not match!"));
                                                            }
                                                        }), 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {})
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-col justify-center items-center w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "bg-secondry py-2 px-3 rounded-md transition-all text-white mt-10",
                                    type: "submit",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Add Employee"
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2364:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ EmployeesData)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(9146);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__, _Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_5__]);
([_client_requests__WEBPACK_IMPORTED_MODULE_3__, _Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function EmployeesData(props) {
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_6__.useSession)();
    const { 0: tabValue , 1: setTabValue  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)("All");
    const { 0: employeesData , 1: setEmployeesData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: filteredEmployeesData , 1: setFilteredEmployeesData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: isEmployeeProfile , 1: setIsEmployeeProfile  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        id: null
    });
    //This function get the new employees when
    //CheckforNewEmployees gets true
    const getEmployeesData = async ()=>{
        setLoading(true);
        const res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getEmployees */ .fN)();
        const data = res.data;
        console.log("EmployeesData:", data);
        if (data) {
            setLoading(false);
        }
        setEmployeesData(data);
        setFilteredEmployeesData(data);
    };
    //** Delete employee */
    const confirm = (id)=>{
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .deleteEmployee */ .P6)(id, session.user.id).then((res)=>{
            console.log(res);
            if (!res.error) {
                //if employees is sucessfully deleted reload all employees and show message
                getEmployeesData();
                antd__WEBPACK_IMPORTED_MODULE_1__.message.success(`Sucessfully removed: ${res.data.deleteEmployee.first_name}`);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.error(`Error while removing employee!`);
            }
        });
    };
    const cancel = (e)=>{
        console.log(e);
        antd__WEBPACK_IMPORTED_MODULE_1__.message.error("Click on No");
    };
    function filterData(id) {
        setFilteredEmployeesData(employeesData.filter((e)=>{
            return e.Role.title == id;
        }));
    }
    //Call the getNewEmployees function when needed
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getEmployeesData();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (tabValue == "All") {
            setFilteredEmployeesData(employeesData);
        } else if (tabValue == "Admins") {
            filterData("Admin");
        } else if (tabValue == "Project Managers") {
            filterData("Project Manager");
        } else if (tabValue == "Operation Managers") {
            filterData("Operation Manager");
        } else if (tabValue == "Team Leads") {
            filterData("Team Lead");
        } else if (tabValue == "Team Members") {
            filterData("Team Member");
        }
    }, [
        tabValue
    ]);
    const columns = [
        {
            title: "Name",
            width: 150,
            render: (_, { first_name , last_name , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "underline cursor-pointer",
                    onClick: ()=>setIsEmployeeProfile({
                            id
                        }),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        children: [
                            first_name,
                            " ",
                            last_name
                        ]
                    })
                }),
            key: "name",
            fixed: "left"
        },
        {
            title: "Age",
            width: 100,
            dataIndex: "date_of_birth",
            key: "age",
            sorter: true,
            render: (_, { date_of_birth  })=>{
                var age = moment_moment__WEBPACK_IMPORTED_MODULE_4___default()().diff(date_of_birth, "years", false);
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    children: [
                        age,
                        " years"
                    ]
                });
            }
        },
        {
            title: "Gender",
            width: 90,
            dataIndex: "gender",
            key: "gender"
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email"
        },
        {
            title: "Phone Number",
            dataIndex: "phone_number",
            key: "phone_number"
        },
        {
            title: "Designation",
            render: (_, { Designation  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: Designation.title
                }),
            key: "designation"
        },
        {
            title: "Role",
            render: (_, { Role  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    children: Role.title
                }),
            key: "role"
        },
        {
            title: "Expertise",
            dataIndex: "expertise",
            key: "expertise"
        },
        {
            title: "Years of Experince",
            dataIndex: "years_of_experience",
            key: "years_of_experience",
            render: (_, { years_of_experience  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    children: [
                        years_of_experience,
                        " years"
                    ]
                })
        },
        {
            title: "Action",
            key: "id",
            fixed: "right",
            render: (_, param)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "p-2 mr-2 bg-secondry rounded-md text-sm text-white",
                            onClick: ()=>props.setUpdateEmployee(param),
                            children: "Update"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Popconfirm, {
                            title: "Delete Employee",
                            description: "Are you sure to remove this employee from projectorate?",
                            onConfirm: ()=>{
                                confirm(param.id);
                            },
                            onCancel: cancel,
                            okText: "Confirm",
                            cancelText: "No",
                            placement: "topLeft",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                className: "p-2 bg-red-500 rounded-md text-sm text-white",
                                children: "Delete"
                            })
                        })
                    ]
                })
        }, 
    ];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                isEmployeeProfile: isEmployeeProfile,
                setIsEmployeeProfile: setIsEmployeeProfile
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col justify-center items-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "py-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Segmented, {
                            options: [
                                "All",
                                "Admins",
                                "Operation Managers",
                                "Project Managers",
                                "Team Lead",
                                "Team Member", 
                            ],
                            value: tabValue,
                            onChange: setTabValue
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "employees_panel_data_table w-full",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
                            columns: columns,
                            dataSource: filteredEmployeesData,
                            scroll: {
                                x: 1300
                            }
                        })
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4125:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ EmployeesPanel)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _EmployeesData__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2364);
/* harmony import */ var _AddEmployee__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3984);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7066);
/* harmony import */ var _ant_design_icons__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_ant_design_icons__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _UpdateEmployee__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6647);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EmployeesData__WEBPACK_IMPORTED_MODULE_1__, _AddEmployee__WEBPACK_IMPORTED_MODULE_2__, _UpdateEmployee__WEBPACK_IMPORTED_MODULE_6__]);
([_EmployeesData__WEBPACK_IMPORTED_MODULE_1__, _AddEmployee__WEBPACK_IMPORTED_MODULE_2__, _UpdateEmployee__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







function EmployeesPanel(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "Employees_panel",
        children: props.addEmployee ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AddEmployee__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
            setAddEmployee: props.setAddEmployee
        }) : props.updateEmployee ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UpdateEmployee__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            updateEmployee: props.updateEmployee,
            setUpdateEmployee: props.setUpdateEmployee
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EmployeesData__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
            setUpdateEmployee: props.setUpdateEmployee
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4694:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ EmployeesPanelContainer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _EmployeesPanel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4125);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_EmployeesPanel__WEBPACK_IMPORTED_MODULE_3__]);
_EmployeesPanel__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





function EmployeesPanelContainer(props) {
    //state to check if user wants to add new employee
    const { 0: addEmployee , 1: setAddEmployee  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: updateEmployee , 1: setUpdateEmployee  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Drawer, {
        title: "Employees Panel",
        onClose: ()=>props.setIsEmployeePanel(false),
        open: props.isEmployeePanel,
        bodyStyle: {
            paddingBottom: 80,
            paddingRight: 10,
            paddingLeft: 10
        },
        width: "100%",
        extra: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
            placement: "bottomRight",
            title: "Add new employee, project manager, modetor to your company",
            mouseEnterDelay: 0.05,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: "bg-primary py-1 px-3 rounded-md flex flex-row justify-center items-center transition-all",
                onClick: ()=>{
                    updateEmployee ? setUpdateEmployee(false) : setAddEmployee(!addEmployee);
                },
                children: addEmployee || updateEmployee ? "Cancel" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: [
                        " ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_2__.IoIosAdd, {
                            size: 26
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Add New Employee"
                        })
                    ]
                })
            })
        }),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EmployeesPanel__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
            addEmployee: addEmployee,
            setAddEmployee: setAddEmployee,
            updateEmployee: updateEmployee,
            setUpdateEmployee: setUpdateEmployee
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6647:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UpdateEmployee)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__]);
_client_requests__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const { Option  } = antd__WEBPACK_IMPORTED_MODULE_1__.Select;
const formItemLayout = {
    labelCol: {
        xs: {
            span: 7
        },
        sm: {
            span: 5
        }
    },
    wrapperCol: {
        xs: {
            span: 22
        },
        sm: {
            span: 18
        }
    }
};
const tailFormItemLayout = {
    wrapperCol: {
        xs: {
            span: 24,
            offset: 0
        },
        sm: {
            span: 8,
            offset: 0
        }
    }
};
function UpdateEmployee(props) {
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_5__.useSession)();
    const { 0: employee , 1: setEmployee  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(props.updateEmployee);
    const { 0: designations , 1: setDesignations  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: roles , 1: setRoles  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(null);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
    const handleEmployeeSubmission = async (payload)=>{
        setLoading(true);
        let res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .UpdateEmployeeAPI */ .RW)(payload);
        console.log(res);
        if (res?.error) {
            antd__WEBPACK_IMPORTED_MODULE_1__.message.error("Employee submission failed!");
            setLoading(false);
        } else {
            antd__WEBPACK_IMPORTED_MODULE_1__.message.success("Employee added successfully!");
            form.resetFields();
            props.setUpdateEmployee(false);
        }
    };
    const onFinish = (values)=>{
        const payload = {
            ...values,
            id: employee.id,
            userId: session.user.id
        };
        handleEmployeeSubmission(payload);
    };
    //get all the designations in the db
    const getAllDesignations = async ()=>{
        const designationsResponse = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getDesignations */ .qI)();
        setDesignations(designationsResponse.data);
    };
    //get all the roles in the db
    const getAllRoles = async ()=>{
        const rolesResponse = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getRoles */ .F3)();
        const data = rolesResponse.data;
        data.splice(0, 1); // remove super-admin from roles
        setRoles(data);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getAllDesignations();
        getAllRoles();
        console.log(employee);
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (designations && roles) {
            setLoading(false);
        }
    }, [
        designations,
        roles
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "container flex w-full flex-col justify-center items-center",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "mb-12 text-base flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "text-xl font-bold ",
                            children: " Update Employee"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Kindly fill out the following form carefully!"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "w-full",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Form, {
                        ...formItemLayout,
                        form: form,
                        name: "register",
                        onFinish: onFinish,
                        style: {
                            width: "100%"
                        },
                        scrollToFirstError: true,
                        disabled: loading,
                        initialValues: {
                            ["firstName"]: employee.first_name,
                            ["lastName"]: employee.last_name,
                            ["email"]: employee.email,
                            ["phoneNumber"]: employee.phone_number,
                            ["address"]: employee.address,
                            ["dateOfBirth"]: moment__WEBPACK_IMPORTED_MODULE_4___default()(employee.date_of_birth),
                            ["dateOfJoining"]: moment__WEBPACK_IMPORTED_MODULE_4___default()(employee.date_of_joining),
                            ["yearsOfExperience"]: employee.years_of_experience,
                            ["gender"]: employee.gender,
                            ["expertise"]: employee.expertise,
                            ["designation"]: employee.designation,
                            ["role"]: employee.role,
                            ["role"]: employee.role
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Row, {
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Col, {
                                        xs: {
                                            span: 22,
                                            offset: 1
                                        },
                                        lg: {
                                            span: 11,
                                            offset: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "firstName",
                                                label: "First Name",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input employee's first name"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "First name must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 20,
                                                        message: "First name must be maximum of 20 characters"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "lastName",
                                                label: "Last Name",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input employee's last name"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "last name must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 20,
                                                        message: "last name must be maximum of 20 characters"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "email",
                                                label: "E-mail",
                                                rules: [
                                                    {
                                                        type: "email",
                                                        message: "The input is not valid E-mail!"
                                                    },
                                                    {
                                                        required: true,
                                                        message: "Please input your E-mail!"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "address",
                                                label: "Address",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please add employee address"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "Address must be minimum of 4 characters"
                                                    },
                                                    {
                                                        max: 40,
                                                        message: "Address must be maximum of 40 characters"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "phoneNumber",
                                                label: "Phone Number",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input your phone number!"
                                                    },
                                                    {
                                                        max: 11,
                                                        message: "Number should be 11 digits long"
                                                    },
                                                    {
                                                        min: 11,
                                                        message: "Number should be 11 digits long"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {
                                                    style: {
                                                        width: "100%"
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "dateOfBirth",
                                                label: "Date of Birth",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input a date of birth!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {
                                                    className: "w-full",
                                                    disabledDate: (current)=>{
                                                        return moment__WEBPACK_IMPORTED_MODULE_4___default()().add(-18, "years") <= current;
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "dateOfJoining",
                                                label: "Date of Join",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input a date of joining for employee!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.DatePicker, {
                                                    className: "w-full",
                                                    disabledDate: (current)=>{
                                                        return moment__WEBPACK_IMPORTED_MODULE_4___default()().add(-1, "years") >= current || moment__WEBPACK_IMPORTED_MODULE_4___default()().add(4, "months") <= current;
                                                    }
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Col, {
                                        xs: {
                                            span: 22,
                                            offset: 1
                                        },
                                        lg: {
                                            span: 11,
                                            offset: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "yearsOfExperience",
                                                label: "Years of experince",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please add years of experience!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.InputNumber, {
                                                    className: "w-full",
                                                    type: "number"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "gender",
                                                label: "Gender",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please a gender!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select gender",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: "male",
                                                            children: "Male"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: "female",
                                                            children: "Female"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "expertise",
                                                label: "Expertise",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input Expertise! E.g Front-end Developer"
                                                    },
                                                    {
                                                        whitespace: true,
                                                        message: "Must be atleast one non-space character!"
                                                    },
                                                    {
                                                        max: 30,
                                                        message: "Maximum length of expertise can be 30 characters long!"
                                                    },
                                                    {
                                                        min: 4,
                                                        message: "Minimum length of expertise can be 4 characters long!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "designation",
                                                label: "Designation",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please select a designation!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select your A designation for employee",
                                                    children: designations?.map((designation)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: designation.id,
                                                            children: designation.title
                                                        }, designation.id);
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "role",
                                                label: "Role",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please select a role!"
                                                    }, 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Select, {
                                                    placeholder: "select your A role for employee",
                                                    children: roles?.map((role)=>{
                                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Option, {
                                                            value: role.id,
                                                            children: role.title
                                                        }, role.id);
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "password",
                                                label: "Password",
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please input your password!"
                                                    },
                                                    {
                                                        min: 8,
                                                        message: "Password must be 8 characters long!"
                                                    }, 
                                                ],
                                                hasFeedback: true,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {})
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                                                name: "confirm",
                                                label: "Confirm Password",
                                                dependencies: [
                                                    "password"
                                                ],
                                                hasFeedback: true,
                                                rules: [
                                                    {
                                                        required: true,
                                                        message: "Please confirm your password!"
                                                    },
                                                    ({ getFieldValue  })=>({
                                                            validator (_, value) {
                                                                if (!value || getFieldValue("password") === value) {
                                                                    return Promise.resolve();
                                                                }
                                                                return Promise.reject(new Error("The two passwords that you entered do not match!"));
                                                            }
                                                        }), 
                                                ],
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input.Password, {})
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "flex flex-col justify-center items-center w-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                    className: "bg-secondry py-2 px-3 rounded-md transition-all text-white mt-10",
                                    type: "submit",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Update Employee"
                                    })
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6380:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ EmployeesContainer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_Uploads_temp_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(591);
/* harmony import */ var _InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7597);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_5__);






function EmployeesContainer({ employeeName ="Employee Name" , designation ="Designation Name" , informationTag ="Web Dev" , role ,  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "Employees-container bg-gray-700 h-20 w-full px-4 mt-2 rounded-md shadow-sm flex flex-row justify-between items-center ",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row justify-between items-center ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "Employee-Image flex flex-row items-center justify-center h-12 w-12 bg-white bg-opacity-10 rounded-xl",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: "text-xl font-bold",
                            children: employeeName[0]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "Employee-information pl-4 lg:w-72 md:w-52",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "",
                                children: employeeName
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-pOrange text-sm",
                                children: designation
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "Employee-work-info-tag sm:flex hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    title: informationTag,
                    type: "intermediate",
                    size: "md"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "Employee-work-info-tag sm:flex hidden",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    title: role,
                    type: "base",
                    size: "md"
                })
            })
        ]
    });
}


/***/ }),

/***/ 1473:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ EmployeesContainerSkelton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_Uploads_temp_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(591);
/* harmony import */ var _InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7597);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1111);
/* harmony import */ var react_icons_hi__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_hi__WEBPACK_IMPORTED_MODULE_4__);





function EmployeesContainerSkelton() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "Employees-container bg-gray-700 h-20 w-full px-4 mt-2 rounded-md shadow-sm flex flex-row justify-between items-center animate-pulse",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row justify-between items-center ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "Employee-Image flex flex-row items-center bg-gray-600 rounded-full",
                        style: {
                            height: 50,
                            width: 50
                        }
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "Employee-information pl-4 lg:w-80 md:w-52",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "bg-gray-600",
                                style: {
                                    height: 16,
                                    width: 150
                                }
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mt-2 rounded-2 bg-gray-600",
                                style: {
                                    height: 10,
                                    width: 100
                                }
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "Employee-work-info-tag bg-gray-600 rounded-2xl",
                style: {
                    height: 30,
                    width: 200
                }
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "Employee-tickets-stat flex flex-row justify-center items-center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                    className: "text-xl text-gray-600",
                    children: "xx / xx"
                })
            })
        ]
    });
}


/***/ }),

/***/ 6653:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SuperAdminEmployees),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_Search_SearchModule__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5905);
/* harmony import */ var _components_Devider_Devider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3588);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(567);
/* harmony import */ var react_icons_bs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var ___WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9637);
/* harmony import */ var _components_Employees_EmployeesContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6380);
/* harmony import */ var _components_Employees_EmployeesContainerSkelton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1473);
/* harmony import */ var _components_AddEmployee_AddEmployee__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3385);
/* harmony import */ var _components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7693);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(598);
/* harmony import */ var _context_notificationContext__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5329);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _components_EmployeesPanel_EmployeesPanelContainer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4694);
/* harmony import */ var _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9146);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([___WEBPACK_IMPORTED_MODULE_4__, _components_AddEmployee_AddEmployee__WEBPACK_IMPORTED_MODULE_7__, _client_requests__WEBPACK_IMPORTED_MODULE_10__, _components_EmployeesPanel_EmployeesPanelContainer__WEBPACK_IMPORTED_MODULE_13__, _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_14__]);
([___WEBPACK_IMPORTED_MODULE_4__, _components_AddEmployee_AddEmployee__WEBPACK_IMPORTED_MODULE_7__, _client_requests__WEBPACK_IMPORTED_MODULE_10__, _components_EmployeesPanel_EmployeesPanelContainer__WEBPACK_IMPORTED_MODULE_13__, _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const { Option  } = antd__WEBPACK_IMPORTED_MODULE_12__.Select;
function SuperAdminEmployees({ data  }) {
    const { 0: isEmployeePanel , 1: setIsEmployeePanel  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(true);
    const { 0: employeesData , 1: setEmployeesData  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(data);
    const { 0: filteredEmployeesData , 1: setFilteredEmployeesData  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(data);
    const { 0: isEmployeeProfile , 1: setIsEmployeeProfile  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)({
        id: null
    });
    //Global Notificatiosn handler
    const { notifications , setNotifications  } = (0,_context_notificationContext__WEBPACK_IMPORTED_MODULE_11__/* .useNotificationsHandler */ .y)();
    //A bool state to check for employees change
    const { 0: checkForNewEmployees , 1: setCheckForNewEmployees  } = (0,react__WEBPACK_IMPORTED_MODULE_9__.useState)(false);
    //Initial Skelton Animation for employees
    setInterval(()=>{
        setLoading(false);
    }, 2500);
    //This function get the new employees when
    //CheckforNewEmployees gets true
    const getNewEmployees = async ()=>{
        if (checkForNewEmployees) {
            setLoading(true);
            const res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_10__/* .getEmployees */ .fN)();
            const data = res.data;
            setCheckForNewEmployees(false);
            setEmployeesData(data);
        }
    };
    //Call the getNewEmployees function when needed
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (checkForNewEmployees) {
            getNewEmployees();
        }
    }, [
        checkForNewEmployees
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_9__.useEffect)(()=>{
        if (loading) {
            setInterval(()=>{
                setLoading(false);
            }, 2500);
        }
    }, [
        loading
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                isEmployeeProfile: isEmployeeProfile,
                setIsEmployeeProfile: setIsEmployeeProfile
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "Employees-panel",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_DashboardHeader_DashboardHeader__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        title: "Employees Panel",
                        type: "employees",
                        icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bs__WEBPACK_IMPORTED_MODULE_3__.BsPeople, {
                            size: 26
                        }),
                        setIsEmployeePanel: setIsEmployeePanel
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "Search-employees-section px-4 my-4",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Search_SearchModule__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {
                            type: "employees",
                            title: "SEARCH EMPLOYEES",
                            description: "Take a dive in to the employees and its attributes. Find anything you are looking for in this employees",
                            data: employeesData,
                            setFilteredData: setFilteredEmployeesData
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Devider_Devider__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                        color: "bg-gray-900",
                        width: "w-full",
                        opacity: "opacity-1"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "All-employees-stack mt-4 px-4",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: "font-semibold text-2xl opacity-80",
                                        children: "ALL EMPLOYEES"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        className: "text-sm opacity-60 mt-1",
                                        children: "A complete list of all the employees in Projectorate."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "Projects py-4 flex flex-col",
                                children: !loading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: filteredEmployeesData?.map((employee)=>{
                                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            onClick: ()=>setIsEmployeeProfile({
                                                    id: employee.id
                                                }),
                                            className: "employee-container cursor-pointer",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_EmployeesContainer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                employeeId: employee.id,
                                                employeeName: employee.first_name + " " + employee.last_name,
                                                designation: employee.expertise,
                                                informationTag: employee.email,
                                                role: employee.Role.title
                                            })
                                        }, employee.id);
                                    })
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_EmployeesContainerSkelton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_EmployeesContainerSkelton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_EmployeesContainerSkelton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_EmployeesContainerSkelton__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {})
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_EmployeesPanel_EmployeesPanelContainer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                isEmployeePanel: isEmployeePanel,
                setIsEmployeePanel: setIsEmployeePanel
            })
        ]
    });
}
// This gets called on every server-side render
async function getServerSideProps() {
    // Fetch data from external API
    let data;
    try {
        const res = await fetch("http://localhost:3000/api" + `/employee/get-employees`);
        data = res.json();
    } catch (error) {
        console.log("Error at server-side for employees: ", error);
    }
    // Pass data to the page via props
    return {
        props: data
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 1077:
/***/ ((module) => {

module.exports = require("@lottiefiles/react-lottie-player");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 2124:
/***/ ((module) => {

module.exports = require("js-file-download");

/***/ }),

/***/ 9699:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 3332:
/***/ ((module) => {

module.exports = require("moment/moment");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 7865:
/***/ ((module) => {

module.exports = require("react-icons/cg");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 1111:
/***/ ((module) => {

module.exports = require("react-icons/hi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,676,1664,5675,598,9146,5329,3049,535,2090,8046,9637], () => (__webpack_exec__(6653)));
module.exports = __webpack_exports__;

})();