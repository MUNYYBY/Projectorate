"use strict";
(() => {
var exports = {};
exports.id = 4750;
exports.ids = [4750,6366];
exports.modules = {

/***/ 3925:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ AssignEmployee)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1946);
/* harmony import */ var react_icons_ti__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_ti__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(598);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_5__]);
_client_requests__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








function AssignEmployee(props) {
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const { 0: searchResults , 1: setSearchResults  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)([]);
    const [form] = antd__WEBPACK_IMPORTED_MODULE_1__.Form.useForm();
    function onFinish(values) {
        console.log(values);
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_5__/* .SearchEmployee */ .g8)(values.SearchEmployee).then((res)=>{
            if (!res.error) {
                setSearchResults(res.data.result);
                console.log(res.data.result);
            }
        });
    }
    function AssignEmployeeConfirm(projectId, employeeId) {
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_5__/* .AssignEmployeeToProject */ .r2)(projectId, employeeId, props.ownerId).then((res)=>{
            console.log(res);
            if (!res.error) {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.success("Employee Sucessfully Added to the project!");
                props.setAssignEmployeesPanel(false);
                props.setisNewEmployee(true);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.error("Some Error Occured while adding Employee to the project!");
            }
        });
    }
    function OnAssignEmployeeCancel() {}
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Drawer, {
        title: "Assign Employee",
        onClose: ()=>props.setAssignEmployeesPanel(false),
        open: props.assignEmployeesPanel,
        bodyStyle: {
            paddingBottom: 80
        },
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_1__.Form, {
                form: form,
                name: "assignEmployees",
                onFinish: onFinish,
                style: {
                    width: "100%"
                },
                scrollToFirstError: true,
                disabled: loading,
                type: "submit",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Form.Item, {
                        name: "SearchEmployee",
                        rules: [
                            {
                                required: true,
                                message: "Please input something to search for employees"
                            }, 
                        ],
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Input, {
                            placeholder: "Search Employees"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                        className: "bg-secondry w-full py-2 px-3 rounded-md transition-all text-white flex justify-center items-center",
                        type: "submit",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_4__.AiOutlineSearch, {
                                size: 18
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "ml-2",
                                children: "Search"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "mt-4 search-results",
                children: [
                    loading && searchResults.length == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex flex-col justify-center items-center",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                            class: "animate-spin -ml-1 h-10 w-10 text-white",
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                    class: "opacity-25",
                                    cx: "12",
                                    cy: "12",
                                    r: "10",
                                    stroke: "currentColor",
                                    strokeWidth: "4"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    class: "opacity-75",
                                    fill: "currentColor",
                                    d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                })
                            ]
                        })
                    }) : searchResults.length == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Empty, {
                        image: antd__WEBPACK_IMPORTED_MODULE_1__.Empty.PRESENTED_IMAGE_SIMPLE,
                        description: "No employees found!"
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                    searchResults.map((employee, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "employee-card flex flex-row justify-between items-center py-4 px-4 mb-2 bg-gray-800 bg-opacity-50 rounded-lg border-2 border-gray-600",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-row justify-center items-center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "bg-gray-600 bg-opacity-50 rounded-md h-14 w-14 flex justify-center items-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-extrabold text-2xl opacity-40",
                                                    children: employee.first_name[0]
                                                })
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "ml-2",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        className: "font-semibold text-lg",
                                                        children: [
                                                            employee.first_name,
                                                            " ",
                                                            employee.last_name
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                        className: "m-0 text-md",
                                                        children: [
                                                            "@",
                                                            employee.email
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Popconfirm, {
                                        title: `Are you sure you want to add ${employee.first_name} to this project?`,
                                        onConfirm: ()=>AssignEmployeeConfirm(props.projectId, employee.id),
                                        onCancel: OnAssignEmployeeCancel,
                                        okText: "Confirm",
                                        cancelText: "No",
                                        placement: "topLeft",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "bg-primary py-1 px-2 rounded-md flex flex-row justify-center items-center",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ti__WEBPACK_IMPORTED_MODULE_3__.TiUserAddOutline, {
                                                size: 26
                                            })
                                        })
                                    })
                                ]
                            }, employee.id + index)
                        });
                    })
                ]
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4526:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CreateProject)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6652);
/* harmony import */ var react_icons_bi__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Devider_Devider__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3588);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _Step1ProjectCreation__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8358);
/* harmony import */ var _Step2ProjectCreation__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7454);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(598);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6197);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_8__, framer_motion__WEBPACK_IMPORTED_MODULE_10__]);
([_client_requests__WEBPACK_IMPORTED_MODULE_8__, framer_motion__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












function CreateProject(props) {
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_9__.useSession)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: projectName , 1: setProjectName  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: projectDetails , 1: setProjectDetails  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: projectDomainSelected , 1: setProjectDomainSelected  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: creationPhase , 1: setCreationPhase  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    const { 0: projectDomains , 1: setProjectDomains  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: isSubmitted , 1: setIsSubmitted  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const createProjectCall = ()=>{
        const payload = {
            project_name: projectName,
            description: projectDetails,
            project_domain_id: projectDomainSelected,
            user_id: session.user.id
        };
        console.log("Project Payload: ", payload);
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_8__/* .createProject */ .$L)(payload).then((res)=>{
            console.log("Create:", res);
            if (res?.error) {
                antd__WEBPACK_IMPORTED_MODULE_5__.message.error("Project Creation failed!");
                setLoading(false);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_5__.message.success("Project Created successfully!");
                props.setIsCreateProject(false);
                props.setIsRefreshProjects(true);
            }
        });
    };
    //get all the project domains on component mount
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoading(true);
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_8__/* .getProjectDomains */ .gA)().then((res)=>{
            console.log("Project Domains: ", res.data);
            setProjectDomains(res.data);
            setLoading(false);
        });
    }, []);
    //call the api
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isSubmitted) {
            setCreationPhase(2);
            setLoading(true);
            createProjectCall();
            setIsSubmitted(false);
        }
    }, [
        isSubmitted
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "create-project-container h-full w-full fixed overflow-hidden top-0 left-0 flex justify-center items-start",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                initial: {
                    y: -100,
                    opacity: 0
                },
                animate: {
                    y: 0,
                    opacity: 1
                },
                transition: {
                    duration: 0.15
                },
                className: "flex flex-col items-center z-10 w-full",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "w-11/12 md:w-[25rem] lg:w-[35rem] mt-20 ",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col items-center p-6 bg-gray-900 rounded-md",
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "create-project-header flex flex-row justify-between w-full mb-6",
                                    children: [
                                        creationPhase == 1 || creationPhase == 2 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                            className: "back-btn flex flex-row items-center opacity-60 hover:opacity-100",
                                            onClick: ()=>setCreationPhase(0),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_bi__WEBPACK_IMPORTED_MODULE_3__.BiArrowBack, {
                                                    size: 18
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                    className: "ml-2",
                                                    children: "Back"
                                                })
                                            ]
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "font-bold text-lg"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "cancel-btn opacity-60 hover:opacity-100",
                                            onClick: ()=>props.setIsCreateProject(false),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_2__.RxCross1, {
                                                size: 24
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col justify-center items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            width: "123",
                                            height: "97",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                                                fill: "none",
                                                "fill-rule": "evenodd",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                        fill: "#7B67EE",
                                                        cx: "61.5",
                                                        cy: "56.5",
                                                        r: "39.5"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M54.57 17.6A39.5 39.5 0 0 0 88.44 85.4 39.5 39.5 0 1 1 54.56 17.6z",
                                                        fill: "#6C5AD4"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M22.25 49.42a39.89 39.89 0 0 0-.54 10.1c-2.55 2.88-3.67 5.68-3.01 8.16 2.2 8.19 23.14 9.7 46.77 3.36 23.64-6.34 41.02-18.11 38.83-26.3-.73-2.74-3.57-4.73-7.9-5.93a39.65 39.65 0 0 0-5.3-7.98c17.32-.7 29.74 2.67 31.64 9.76 3.04 11.32-21.92 27.84-55.75 36.9C33.17 86.57 3.3 84.74.26 73.42c-1.88-7 6.96-16 21.99-24z",
                                                        fill: "#C1B6FF",
                                                        opacity: ".4"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M22 50.97a39.7 39.7 0 0 0-.2 1.54C12.4 58.61 7.24 65.1 8.66 70.37c2.7 10.11 28.57 11.97 57.76 4.15 29.19-7.82 50.65-22.36 47.94-32.47-1.46-5.45-9.64-8.5-21.45-8.94-.26-.36-.54-.72-.82-1.08 15.21-.26 25.97 2.95 27.68 9.36 2.89 10.77-20.86 26.49-53.03 35.11-32.18 8.62-60.6 6.88-63.5-3.89C1.55 66.3 9.04 58.26 22 50.97zm-.32 3.13c-.05.72-.07 1.45-.08 2.18-5.35 4.38-8.05 8.78-7.05 12.5 2.4 9 25.38 10.64 51.3 3.7 25.94-6.95 45.01-19.87 42.6-28.85-1.05-3.94-6.05-6.47-13.52-7.48-.36-.6-.74-1.2-1.13-1.77 9.9.72 16.67 3.57 17.95 8.36 2.58 9.62-17.83 23.44-45.58 30.88-27.76 7.44-52.35 5.67-54.92-3.95-1.24-4.6 2.81-10.19 10.43-15.57z",
                                                        fill: "#C1B6FF",
                                                        opacity: ".4"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                                        fill: "#B4A7FF",
                                                        cx: "34.5",
                                                        cy: "29.5",
                                                        r: "12.5"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M29.45 18.06a12.5 12.5 0 0 0 15.1 18.88 12.5 12.5 0 1 1-15.1-18.88z",
                                                        fill: "#9A8CED"
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                        d: "M104.72 6.72l1.84-5.24a1 1 0 0 1 1.88 0l1.84 5.24 5.24 1.84a1 1 0 0 1 0 1.88l-5.24 1.84-1.84 5.24a1 1 0 0 1-1.88 0l-1.84-5.24-5.24-1.84a1 1 0 0 1 0-1.88l5.24-1.84zM75.93 4.93l.63-1.8a1 1 0 0 1 1.88 0l.63 1.8 1.8.63a1 1 0 0 1 0 1.88l-1.8.63-.63 1.8a1 1 0 0 1-1.88 0l-.63-1.8-1.8-.63a1 1 0 0 1 0-1.88l1.8-.63zM17.78 92.78l.28-.8a1 1 0 0 1 1.88 0l.28.8.8.28a1 1 0 0 1 0 1.88l-.8.28-.28.8a1 1 0 0 1-1.88 0l-.28-.8-.8-.28a1 1 0 0 1 0-1.88l.8-.28z",
                                                        fill: "#E6E2FF"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                            className: "font-bold text-xl my-4",
                                            children: "Create a new Project"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Devider_Devider__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    width: "w-full"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "w-full my-4",
                                    children: creationPhase == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Step1ProjectCreation__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                        setProjectName: setProjectName,
                                        projectName: projectName,
                                        setCreationPhase: setCreationPhase,
                                        loading: loading
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Step2ProjectCreation__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                                        loading: loading,
                                        setProjectDetails: setProjectDetails,
                                        setCreationPhase: setCreationPhase,
                                        projectDomains: projectDomains,
                                        setProjectDomainSelected: setProjectDomainSelected,
                                        setIsSubmitted: setIsSubmitted
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "w-full flex justify-center items-center mt-8",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_5__.Steps, {
                                current: creationPhase,
                                labelPlacement: "vertical",
                                items: [
                                    {
                                        title: "Name"
                                    },
                                    {
                                        title: "Details"
                                    },
                                    {
                                        title: "Create"
                                    }, 
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_10__.motion.div, {
                initial: {
                    opacity: 0
                },
                animate: {
                    opacity: 1
                },
                transition: {
                    duration: 0.3
                },
                className: "h-full w-full bg-black bg-opacity-75 absolute top-0 left-0 z-0"
            })
        ]
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8358:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step1ProjectCreation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);




function Step1ProjectCreation(props) {
    const [form] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
    function onFinish(values) {
        props.setProjectName(values.project_name);
        props.setCreationPhase(1);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Form, {
            form: form,
            layout: "vertical",
            name: "create project - part 1",
            onFinish: onFinish,
            style: {
                width: "100%"
            },
            scrollToFirstError: true,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "project_name",
                    label: "Project Name",
                    rules: [
                        {
                            required: true,
                            message: "Please enter valid project name"
                        },
                        {
                            min: 5,
                            message: "Project name must be atleast 5 characters long!"
                        },
                        {
                            whitespace: true,
                            message: "Project name must be atleast 1 non-whitespace character!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        placeholder: "Enter a project name",
                        value: props.projectName
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-primary h-12 p-2 rounded-md flex flex-row justify-center items-center w-full text-lg font-semibold mt-4 disabled:opacity-50",
                    disabled: props.loading,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Next"
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 7454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Step2ProjectCreation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);




function Step2ProjectCreation(props) {
    const [form] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
    function onFinish(values) {
        props.setProjectDetails(values.project_description);
        props.setProjectDomainSelected(values.project_domain);
        props.setIsSubmitted(true);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-full",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Form, {
            form: form,
            layout: "vertical",
            name: "create project - part 2",
            onFinish: onFinish,
            style: {
                width: "100%"
            },
            scrollToFirstError: true,
            disabled: props.loading,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "project_domain",
                    label: "Project Domain",
                    rules: [
                        {
                            required: true,
                            message: "Please select a Project Domain!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select, {
                        placeholder: "Select your a domain for the project",
                        children: props.projectDomains.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select.Option, {
                                value: item.id,
                                children: item.title
                            }, item.id);
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "project_description",
                    label: "Project Description",
                    rules: [
                        {
                            required: true,
                            message: "Please enter valid project description"
                        },
                        {
                            min: 5,
                            message: "Project description must be atleast 5 characters long!"
                        },
                        {
                            whitespace: true,
                            message: "Project description must be atleast 1 non-whitespace character!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        placeholder: "Enter a project description"
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-primary h-12 p-2 rounded-md flex flex-row justify-center items-center w-full text-lg font-semibold mt-4 disabled:opacity-50",
                    disabled: props.loading,
                    children: props.loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                        class: "animate-spin -ml-1 h-5 w-5 text-white",
                        xmlns: "http://www.w3.org/2000/svg",
                        fill: "none",
                        viewBox: "0 0 24 24",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                class: "opacity-25",
                                cx: "12",
                                cy: "12",
                                r: "10",
                                stroke: "currentColor",
                                "stroke-width": "4"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                class: "opacity-75",
                                fill: "currentColor",
                                d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                            })
                        ]
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Create Project"
                    })
                })
            ]
        })
    });
}


/***/ }),

/***/ 8686:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProjectEmployees)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3802);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__]);
_client_requests__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







function ProjectEmployees({ projectId , isNewEmployee , setisNewEmployee , setIsEmployeeProfile , ownerId ,  }) {
    const { 0: employeesData , 1: setEmployeesData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const columns = [
        {
            title: "Name",
            width: 100,
            render: (_, { first_name , last_name , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "underline cursor-pointer",
                    onClick: ()=>setIsEmployeeProfile({
                            id
                        }),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                        children: [
                            first_name,
                            " ",
                            last_name
                        ]
                    })
                }),
            key: "name",
            fixed: "left"
        },
        {
            title: "Age",
            width: 100,
            dataIndex: "date_of_birth",
            key: "age",
            sorter: true,
            render: (_, { date_of_birth  })=>{
                var age = moment_moment__WEBPACK_IMPORTED_MODULE_4___default()().diff(date_of_birth, "years", false);
                return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                    children: [
                        age,
                        " years"
                    ]
                });
            }
        },
        {
            title: "Gender",
            dataIndex: "gender",
            key: "gender"
        },
        {
            title: "Email",
            dataIndex: "email",
            key: "email"
        },
        {
            title: "Phone Number",
            dataIndex: "phone_number",
            key: "phone_number"
        },
        {
            title: "Designation",
            dataIndex: "designation",
            key: "designation"
        },
        // {
        //   title: "Role",
        //   dataIndex: "role",
        //   key: "role",
        // },
        {
            title: "Expertise",
            dataIndex: "expertise",
            key: "expertise"
        },
        {
            title: "Action",
            key: "id",
            fixed: "right",
            width: 100,
            render: (_, { id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    grantPermissionFor: "manage_projects",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Popconfirm, {
                        title: `Remove Employee from project`,
                        description: "Are you sure to remove this employee from projectorate?",
                        onConfirm: ()=>{
                            confirm(id);
                        },
                        onCancel: cancel,
                        okText: "Confirm",
                        cancelText: "No",
                        placement: "topLeft",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "p-2 bg-red-500 rounded-md text-sm text-white",
                            children: "Remove"
                        })
                    })
                })
        }, 
    ];
    //This function get the new employees when
    //CheckforNewEmployees gets true
    const getEmployeesData = async ()=>{
        setLoading(true);
        const res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getProjectEmployees */ .lU)(projectId).then((res)=>{
            const data = res.result;
            console.log("ProjectEmployeesData:", data);
            if (data) {
                setLoading(false);
            }
            setEmployeesData(data);
        });
    };
    const confirm = (id)=>{
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .DeleteEmployeeFromProject */ .ah)(id, projectId, ownerId).then((res)=>{
            console.log(res);
            if (!res.error) {
                //if employees is sucessfully deleted reload all employees and show message
                getEmployeesData();
                antd__WEBPACK_IMPORTED_MODULE_1__.message.success(`Sucessfully removed employee from project!`);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.error(`Error while removing employee!`);
            }
        });
    };
    const cancel = (e)=>{};
    //fetch employee if a new employee has been added
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (isNewEmployee) {
            getEmployeesData();
            setisNewEmployee(false);
        }
    }, [
        isNewEmployee
    ]);
    //Call the getNewEmployees function when needed
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getEmployeesData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex flex-col justify-center items-center -mt-4",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "project_employees_data_table w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
                columns: columns,
                dataSource: employeesData,
                scroll: {
                    x: 1000
                },
                className: "rounded-none",
                style: {
                    borderRadius: "0 !impotant"
                },
                loading: loading,
                rowClassName: ()=>"team-employees"
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4893:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProjectTeams)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3332);
/* harmony import */ var moment_moment__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(moment_moment__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7597);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(3802);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__]);
_client_requests__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];









function ProjectTeams({ projectId , isNewEmployee , setisNewEmployee ,  }) {
    const { 0: teamsData , 1: setTeamsData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(false);
    const columns = [
        {
            title: "Team Name",
            width: 150,
            render: (_, { team_name , id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_6___default()), {
                    href: `/app/u/teams?teamId=${id}&teamName=${team_name}`,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                        className: "cursor-pointer underline",
                        children: team_name
                    })
                }),
            key: "team_name",
            fixed: "left"
        },
        {
            title: "Description",
            dataIndex: "description",
            width: 400,
            key: "description"
        },
        {
            title: "Project",
            render: (_, { project  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    title: project.project_name,
                    type: "secondry",
                    size: "lg"
                }),
            key: "projectId"
        },
        {
            title: "Team Domain",
            render: (_, { TeamDomains  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    title: TeamDomains.title,
                    type: "pOrange",
                    size: "lg"
                }),
            key: "teamDomainsId"
        },
        {
            title: "Action",
            key: "id",
            fixed: "right",
            width: 100,
            render: (_, { id  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    grantPermissionFor: "manage_projects",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Popconfirm, {
                        title: `Remove Team from project`,
                        description: "Are you sure to remove this team from project?",
                        onConfirm: ()=>{
                            confirm(id);
                        },
                        onCancel: cancel,
                        okText: "Confirm",
                        cancelText: "No",
                        placement: "topLeft",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "p-2 bg-red-500 rounded-md text-sm text-white",
                            children: "Remove"
                        })
                    })
                })
        }, 
    ];
    //This function get the new employees when
    //CheckforNewEmployees gets true
    const getTeamsData = async ()=>{
        setLoading(true);
        const res = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getProjectTeams */ .T8)(projectId).then((res)=>{
            if (res.data) {
                setLoading(false);
                setTeamsData(res.data);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.error("Error while fetching project teams!");
            }
        });
    };
    const confirm = (id)=>{
        console.log(id);
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .DeleteTeam */ .ps)(id).then((res)=>{
            console.log(res);
            if (!res.error) {
                //if employees is sucessfully deleted reload all employees and show message
                getTeamsData();
                antd__WEBPACK_IMPORTED_MODULE_1__.message.success(`Sucessfully removed team from project!`);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_1__.message.error(`Error while removing team from project!`);
            }
        });
    };
    const cancel = (e)=>{};
    //fetch employee if a new employee has been added
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (isNewEmployee) {
            getTeamsData();
            setisNewEmployee(false);
        }
    }, [
        isNewEmployee
    ]);
    //Call the getNewEmployees function when needed
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        getTeamsData();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex flex-col justify-center items-center -mt-4",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "project_employees_data_table w-full",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_1__.Table, {
                columns: columns,
                dataSource: teamsData,
                scroll: {
                    x: 1000
                },
                className: "rounded-none",
                style: {
                    borderRadius: "0 !impotant"
                },
                loading: loading,
                rowClassName: ()=>"team-employees"
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ ProjectsContainerSkelton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

function ProjectsContainerSkelton() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "animate-pulse h-44 w-full md:w-96 bg-gray-700 rounded-md shadow-sm p-6 flex flex-col justify-between",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "rounded-lg w-14 h-14 bg-gray-600 flex justify-center items-center"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "projects-container-main-info ml-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                className: "pb-1 text-xl font-semibold h-6 w-32 rounded-md bg-gray-600"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "project-tags flex flex-row",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                    className: "mt-4 text-xl font-semibold h-4 w-24 rounded-md bg-gray-600"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "projects-attributes flex flex-row justify-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rounded-lg w-20 h-10 bg-gray-600 flex justify-center items-center"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rounded-lg w-20 h-10 bg-gray-600 flex justify-center items-center"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex flex-col items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "rounded-lg w-20 h-10 bg-gray-600 flex justify-center items-center"
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 7460:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ UpdateProject)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(598);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_client_requests__WEBPACK_IMPORTED_MODULE_3__]);
_client_requests__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






function UpdateProject({ projectInformation , setIsUpdateProject ,  }) {
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.useSession)();
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: projectDomains , 1: setProjectDomains  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [form] = antd__WEBPACK_IMPORTED_MODULE_2__.Form.useForm();
    function onFinish(values) {
        setLoading(true);
        const payload = {
            ...values,
            id: projectInformation.id,
            user_id: session.user.id
        };
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .UpdateProjectAPI */ .Jh)(payload).then((res)=>{
            if (res.data) {
                antd__WEBPACK_IMPORTED_MODULE_2__.message.success("Project updated Sucessfully!");
                setIsUpdateProject(false);
                setLoading(false);
            } else {
                antd__WEBPACK_IMPORTED_MODULE_2__.message.error("Project update Failed!");
                setLoading(false);
            }
        });
    }
    //get all the project domains on component mount
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setLoading(true);
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_3__/* .getProjectDomains */ .gA)().then((res)=>{
            console.log("Project Domains: ", res.data);
            setProjectDomains(res.data);
            setLoading(false);
        });
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "md:ml-4",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(antd__WEBPACK_IMPORTED_MODULE_2__.Form, {
            form: form,
            layout: "vertical",
            name: "create project - part 1",
            onFinish: onFinish,
            style: {
                width: "100%"
            },
            scrollToFirstError: true,
            disabled: loading,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "project_name",
                    rules: [
                        {
                            required: true,
                            message: "Please enter valid project name"
                        },
                        {
                            min: 5,
                            message: "Project name must be atleast 5 characters long!"
                        },
                        {
                            whitespace: true,
                            message: "Project name must be atleast 1 non-whitespace character!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        placeholder: "Enter a project name",
                        defaultValue: projectInformation.project_name
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "project_domain_id",
                    rules: [
                        {
                            required: true,
                            message: "Please select a Project Domain!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select, {
                        placeholder: "Select your a domain for the project",
                        children: projectDomains.map((item)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Select.Option, {
                                value: item.id,
                                children: item.title
                            }, item.id);
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Form.Item, {
                    name: "description",
                    rules: [
                        {
                            required: true,
                            message: "Please enter valid project description"
                        },
                        {
                            min: 5,
                            message: "Project description must be atleast 5 characters long!"
                        },
                        {
                            whitespace: true,
                            message: "Project description must be atleast 1 non-whitespace character!"
                        }, 
                    ],
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_2__.Input, {
                        placeholder: "Enter a project description",
                        defaultValue: projectInformation.description
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "bg-white bg-opacity-10 hover:bg-opacity-20 transition-all w-24 h-10 p-2 mr-2 rounded-md flex flex-row justify-center items-center text-lg font-semibold mt-4 disabled:opacity-50",
                            onClick: ()=>setIsUpdateProject(false),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Cancel"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "bg-primary w-24 h-10 p-2 rounded-md flex flex-row justify-center items-center text-lg font-semibold mt-4 disabled:opacity-50",
                            disabled: loading,
                            children: loading ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
                                class: "animate-spin -ml-1 h-5 w-5 text-white",
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("circle", {
                                        class: "opacity-25",
                                        cx: "12",
                                        cy: "12",
                                        r: "10",
                                        stroke: "currentColor",
                                        "stroke-width": "4"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                        class: "opacity-75",
                                        fill: "currentColor",
                                        d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Update"
                            })
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2890:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ SuperAdminProjectPanel),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_Search_SearchModule__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5905);
/* harmony import */ var _components_Devider_Devider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3588);
/* harmony import */ var _components_Projects_ProjectsContainer_ProjectsContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6166);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5065);
/* harmony import */ var react_icons_sl__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_icons_sl__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4751);
/* harmony import */ var react_icons_io__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_icons_io__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9847);
/* harmony import */ var react_icons_ai__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_icons_ai__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(7865);
/* harmony import */ var react_icons_cg__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_icons_cg__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5725);
/* harmony import */ var antd__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(antd__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_Projects_CreateProject_CreateProject__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4526);
/* harmony import */ var _client_requests__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(598);
/* harmony import */ var _components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(1021);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5452);
/* harmony import */ var react_icons_rx__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_icons_rx__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _components_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7597);
/* harmony import */ var _components_Projects_ProjectEmployees_js_ProjectEmployees__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(8686);
/* harmony import */ var _components_Projects_AssignEmployee_AssignEmployee__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3925);
/* harmony import */ var _components_Tickets_CreateTicketBtn__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(5936);
/* harmony import */ var _components_Tickets_CreateTicketModel__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1026);
/* harmony import */ var _components_Projects_ProjectTeams_ProjectTeams_js__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(4893);
/* harmony import */ var _components_Tickets_AllTickets_AllTickets__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(1072);
/* harmony import */ var _components_Tickets_TicketInfo_TicketInfo__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(7153);
/* harmony import */ var _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(9146);
/* harmony import */ var _Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(3802);
/* harmony import */ var _components_Projects_UpdateProject_UpdateProject__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(7460);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_26__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_Projects_CreateProject_CreateProject__WEBPACK_IMPORTED_MODULE_10__, _client_requests__WEBPACK_IMPORTED_MODULE_11__, _components_Projects_ProjectEmployees_js_ProjectEmployees__WEBPACK_IMPORTED_MODULE_16__, _components_Projects_AssignEmployee_AssignEmployee__WEBPACK_IMPORTED_MODULE_17__, _components_Tickets_CreateTicketModel__WEBPACK_IMPORTED_MODULE_19__, _components_Projects_ProjectTeams_ProjectTeams_js__WEBPACK_IMPORTED_MODULE_20__, _components_Tickets_AllTickets_AllTickets__WEBPACK_IMPORTED_MODULE_21__, _components_Tickets_TicketInfo_TicketInfo__WEBPACK_IMPORTED_MODULE_22__, _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_23__, _components_Projects_UpdateProject_UpdateProject__WEBPACK_IMPORTED_MODULE_25__]);
([_components_Projects_CreateProject_CreateProject__WEBPACK_IMPORTED_MODULE_10__, _client_requests__WEBPACK_IMPORTED_MODULE_11__, _components_Projects_ProjectEmployees_js_ProjectEmployees__WEBPACK_IMPORTED_MODULE_16__, _components_Projects_AssignEmployee_AssignEmployee__WEBPACK_IMPORTED_MODULE_17__, _components_Tickets_CreateTicketModel__WEBPACK_IMPORTED_MODULE_19__, _components_Projects_ProjectTeams_ProjectTeams_js__WEBPACK_IMPORTED_MODULE_20__, _components_Tickets_AllTickets_AllTickets__WEBPACK_IMPORTED_MODULE_21__, _components_Tickets_TicketInfo_TicketInfo__WEBPACK_IMPORTED_MODULE_22__, _components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_23__, _components_Projects_UpdateProject_UpdateProject__WEBPACK_IMPORTED_MODULE_25__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



























const PROJECTS_TABS = [
    "Employees",
    "Teams",
    "Tickets"
];
function SuperAdminProjectPanel({ projectsData , projectDomains ,  }) {
    //** Router Initialization */
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_14__.useRouter)();
    //** React States */
    const { 0: projects , 1: setProjects  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(projectsData);
    const { 0: filteredProjectsData , 1: setFilteredProjectsData  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(projectsData);
    const { 0: isCreateProject , 1: setIsCreateProject  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: isRefreshProjects , 1: setIsRefreshProjects  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: activeProject , 1: setActiveProject  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: projectInformation , 1: setProjectInformation  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
    const { 0: assignEmployeesPanel , 1: setAssignEmployeesPanel  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: isNewEmployee , 1: setisNewEmployee  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: isCreateTicket , 1: setIsCreateTicket  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: activeTab , 1: setActiveTab  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1); // 1 is employees
    const { 0: isTicketInfo , 1: setIsTicketInfo  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        id: null
    });
    const { 0: isEmployeeProfile , 1: setIsEmployeeProfile  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        id: null
    });
    const { 0: isUpdateProject , 1: setIsUpdateProject  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_26__.useSession)();
    //** Get All the projects in CSR */
    const fetchAllProjects = async ()=>{
        await (0,_client_requests__WEBPACK_IMPORTED_MODULE_11__/* .getAllProjects */ .Yw)().then((res)=>{
            setProjects(res.data);
            setFilteredProjectsData(res.data);
            setIsRefreshProjects(false);
        });
    };
    //** When a new project has been added refresh all the projects */
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (isRefreshProjects) {
            fetchAllProjects();
        }
    }, [
        isRefreshProjects
    ]);
    //** Handle when user click on a project */
    function handleActiveProject(project) {
        setActiveProject(project);
        router.push({
            pathname: "/app/u/projects",
            query: {
                projectId: project.id,
                projectName: project.name
            },
            shallow: true
        });
    }
    function handleUnActiveProject() {
        setActiveProject(null);
        setProjectInformation(null);
        router.replace({
            pathname: "/app/u/projects",
            query: undefined,
            shallow: true
        });
    }
    //** Listen for query params change */
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(()=>{
        if (router.query.projectId && router.query.projectName) {
            setActiveProject({
                id: router.query.projectId,
                name: router.query.projectName
            });
            //** Get project Information */
            (0,_client_requests__WEBPACK_IMPORTED_MODULE_11__/* .GetSpecificProject */ .mX)(router.query.projectId).then((res)=>{
                if (!res.error) {
                    console.log(res.data);
                    setProjectInformation(res.data);
                } else {
                    if (res.error.error == 404) {
                        antd__WEBPACK_IMPORTED_MODULE_9__.message.error("Team not found!");
                    }
                    handleUnActiveProject();
                }
            });
        }
    }, [
        router.query
    ]);
    //** Delete project */
    function DeleteProjectConfirm() {
        (0,_client_requests__WEBPACK_IMPORTED_MODULE_11__/* .DeleteProject */ .Qo)(activeProject.id, session?.user.id).then((res)=>{
            if (!res.error) {
                antd__WEBPACK_IMPORTED_MODULE_9__.message.success("Project Sucessfully deleted!");
                handleUnActiveProject();
            } else {
                antd__WEBPACK_IMPORTED_MODULE_9__.message.error("Error deleting project!");
            }
        });
    }
    function OnProjectDeleteCancel() {}
    //** Handle project domains information */
    function handleProjectDomainsInfo(id) {
        return projectDomains.find((domain)=>domain.id == id);
    }
    function handleOnTabChange(value) {
        setActiveTab(value);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                grantPermissionFor: "manage_tickets",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "fixed z-[999] bottom-4 right-4 flex flex-col items-end",
                    children: [
                        isCreateTicket ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Tickets_CreateTicketModel__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                            setIsCreateTicket: setIsCreateTicket
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "Create-ticket",
                            onClick: ()=>setIsCreateTicket(true),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Tickets_CreateTicketBtn__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "Project-panel",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("header", {
                        className: "flex flex-row items-center justify-between border-b-2 border-b-gray-900 px-4 py-2 relative",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row items-center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "project-panel-icon mr-3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoMdGitNetwork, {
                                            size: 26
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                        className: `text-lg font-bold hidden sm:flex`,
                                        children: "Project Panel"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `absolute -bottom-0 left-16 sm:left-52`,
                                children: activeProject ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "border-x-2 border-t-2 border-gray-900 bg-gray-900 rounded-t-md px-4 py-2 flex flex-row justify-between items-center",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: activeProject.name
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "ml-4 opacity-30 hover:opacity-100 transition-all cursor-pointer",
                                            onClick: ()=>handleUnActiveProject(),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_rx__WEBPACK_IMPORTED_MODULE_13__.RxCross1, {
                                                size: 14
                                            })
                                        })
                                    ]
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex flex-row items-center",
                                children: [
                                    !activeProject ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                        grantPermissionFor: "manage_projects",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Tooltip, {
                                            placement: "bottom",
                                            title: "Create a new project in your company and add a workforce",
                                            mouseEnterDelay: 0.05,
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
                                                className: "bg-secondry mr-2 py-1 px-3 rounded-md flex flex-row justify-center items-center",
                                                onClick: ()=>!setIsCreateProject(!isCreateProject),
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoIosAdd, {
                                                        size: 26
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        children: "Create Project"
                                                    })
                                                ]
                                            })
                                        })
                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "help-icon px-2 sm:flex hidden",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_8__.CgInbox, {
                                            size: 24
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "inbox-icon px-2 sm:flex hidden",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_io__WEBPACK_IMPORTED_MODULE_6__.IoIosHelpCircle, {
                                            size: 26
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    !activeProject || !projectInformation ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "Search-projects-section px-4 my-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Search_SearchModule__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    type: "projects",
                                    title: "SEARCH PROJECTS",
                                    description: "Take a dive in to the project and its attributes. Find anything you are looking for in this project",
                                    data: projects,
                                    setFilteredData: setFilteredProjectsData
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Devider_Devider__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                                color: "bg-gray-900",
                                width: "w-full",
                                opacity: "opacity-1"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "All-projects-stack mt-4 px-4",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                className: "font-bold text-xl",
                                                children: "ALL PROJECTS"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "text-sm opacity-60 mt-1",
                                                children: "A complete list of all the projects in Projectorate."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "Projects py-4",
                                        children: [
                                            filteredProjectsData.length == 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "w-full flex justify-center items-center",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Result, {
                                                    status: "404",
                                                    title: "No projects found!",
                                                    subTitle: "Could not found any projects, please create new project in you workspace."
                                                })
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                class: "inline-grid grid-cols-1 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 grid-flow-row gap-4 w-full",
                                                children: !isRefreshProjects ? filteredProjectsData.map((item)=>{
                                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                        className: "project_container cursor-pointer",
                                                        onClick: ()=>handleActiveProject({
                                                                name: item.project_name,
                                                                id: item.id
                                                            }),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                                            ProjectName: item.project_name,
                                                            employeesCount: item._count.userProjects,
                                                            teamsCount: item._count.Teams,
                                                            ticketsCount: item._count.Tickets,
                                                            tagTitle: handleProjectDomainsInfo(item.projectDomainsId).title
                                                        })
                                                    }, item.id);
                                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {}),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectsContainer_ProjectsContainerSkelton__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {})
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isCreateProject ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_CreateProject_CreateProject__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                setIsRefreshProjects: setIsRefreshProjects,
                                setIsCreateProject: setIsCreateProject
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                        ]
                    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_AssignEmployee_AssignEmployee__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                assignEmployeesPanel: assignEmployeesPanel,
                                setAssignEmployeesPanel: setAssignEmployeesPanel,
                                setisNewEmployee: setisNewEmployee,
                                projectId: activeProject.id,
                                ownerId: session?.user.id
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: `${activeProject.name}-project bg-gray-900 bg-opacity-60`,
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "py-10 flex flex-col sm:flex-row justify-between sm:items-start px-3 sm:px-6",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-row justify-start items-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "bg-gray-700 md:flex hidden lg:h-52 lg:w-52 md:h-32 md:w-32 h-24 w-24 rounded-lg flex justify-center items-center",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                        className: "font-extrabold lg:text-[10rem] md:text-6xl text-3xl opacity-40",
                                                        children: activeProject.name[0]
                                                    })
                                                }),
                                                !isUpdateProject ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "flex flex-col justify-center sm:ml-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                                            className: "text-3xl font-bold text-secondry ",
                                                            children: projectInformation?.project_name.toUpperCase()
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                            className: "font-medium mt-2 text-sm md:text-md lg:text-xl sm:w-32 lg:w-96 md:w-32 w-full",
                                                            children: projectInformation?.description
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            className: "mt-4",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_InformationTag_InformationTag__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                                title: handleProjectDomainsInfo(projectInformation?.projectDomainsId).title,
                                                                type: "intermediate"
                                                            })
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_UpdateProject_UpdateProject__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                                    projectInformation: projectInformation,
                                                    setIsUpdateProject: setIsUpdateProject
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Permissions_AuthorityCheck__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                            grantPermissionFor: "manage_projects",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                className: "project-actions flex flex-row mt-4 sm:mt-0",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Tooltip, {
                                                        placement: "topRight",
                                                        title: "Add employees to work on this project",
                                                        mouseEnterDelay: 0.05,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            className: "bg-white bg-opacity-10 hover:bg-opacity-25 transition-all mr-2 p-2 rounded-lg flex flex-row justify-center items-center",
                                                            onClick: ()=>setAssignEmployeesPanel(true),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_7__.AiOutlineUsergroupAdd, {
                                                                size: 24
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Tooltip, {
                                                        placement: "topRight",
                                                        title: "Edit this project",
                                                        mouseEnterDelay: 0.05,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            className: `${isUpdateProject ? "bg-primary" : "bg-white bg-opacity-10 hover:bg-opacity-25"}  transition-all mr-2 p-2 rounded-lg flex flex-row justify-center items-center`,
                                                            onClick: ()=>setIsUpdateProject(!isUpdateProject),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_ai__WEBPACK_IMPORTED_MODULE_7__.AiOutlineEdit, {
                                                                size: 24
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Tooltip, {
                                                        placement: "topRight",
                                                        title: "Remove this project",
                                                        mouseEnterDelay: 0.05,
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Popconfirm, {
                                                            title: `Remove project Projectorate?`,
                                                            description: "Are you sure to remove this project from projectorate?",
                                                            onConfirm: ()=>{
                                                                DeleteProjectConfirm(activeProject.id);
                                                            },
                                                            onCancel: OnProjectDeleteCancel,
                                                            okText: "Confirm",
                                                            cancelText: "No",
                                                            placement: "bottomLeft",
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                                className: "bg-white bg-opacity-10 hover:bg-opacity-25 transition-all mr-2 p-2 rounded-lg flex flex-row justify-center items-center",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_cg__WEBPACK_IMPORTED_MODULE_8__.CgTrash, {
                                                                    size: 24
                                                                })
                                                            })
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mt-4",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(antd__WEBPACK_IMPORTED_MODULE_9__.Tabs, {
                                    defaultActiveKey: "1",
                                    type: "card",
                                    size: 32,
                                    onChange: (value)=>{
                                        handleOnTabChange(value);
                                    },
                                    items: PROJECTS_TABS.map((_, i)=>{
                                        const id = String(i + 1);
                                        return {
                                            label: `${_}`,
                                            key: id
                                        };
                                    })
                                })
                            }),
                            activeTab == 1 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Employees_Profile_EmployeesProfile__WEBPACK_IMPORTED_MODULE_23__/* ["default"] */ .Z, {
                                        isEmployeeProfile: isEmployeeProfile,
                                        setIsEmployeeProfile: setIsEmployeeProfile
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectEmployees_js_ProjectEmployees__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                        projectId: activeProject.id,
                                        isNewEmployee: isNewEmployee,
                                        setisNewEmployee: setisNewEmployee,
                                        setIsEmployeeProfile: setIsEmployeeProfile,
                                        ownerId: session?.user.id
                                    })
                                ]
                            }) : activeTab == 2 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Projects_ProjectTeams_ProjectTeams_js__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                projectId: activeProject.id,
                                isNewEmployee: isNewEmployee,
                                setisNewEmployee: setisNewEmployee
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Tickets_TicketInfo_TicketInfo__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                                        isTicketInfo: isTicketInfo,
                                        setIsTicketInfo: setIsTicketInfo
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Tickets_AllTickets_AllTickets__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {
                                        projectId: activeProject.id,
                                        isNewEmployee: isNewEmployee,
                                        setisNewEmployee: setisNewEmployee,
                                        setIsTicketInfo: setIsTicketInfo
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
}
// This gets called on every server-side render
async function getServerSideProps() {
    // Fetch data from external API
    let projects = null;
    let projectDomains = null;
    //get all the projects
    try {
        const allProjects = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_11__/* .getAllProjects */ .Yw)();
        projects = allProjects.data;
    } catch (error) {
        console.log("Error at server-side for users projects: ", error);
    }
    //get all the projects domains
    try {
        const allProjectsDomains = await (0,_client_requests__WEBPACK_IMPORTED_MODULE_11__/* .getProjectDomains */ .gA)();
        projectDomains = allProjectsDomains.data;
        console.log(projectDomains);
    } catch (error1) {
        console.log("Error at server-side for users projects: ", error1);
    }
    // Pass data to the page via props
    return {
        props: {
            projectsData: projects,
            projectDomains
        }
    };
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7066:
/***/ ((module) => {

module.exports = require("@ant-design/icons");

/***/ }),

/***/ 5725:
/***/ ((module) => {

module.exports = require("antd");

/***/ }),

/***/ 2124:
/***/ ((module) => {

module.exports = require("js-file-download");

/***/ }),

/***/ 9699:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 2245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 3332:
/***/ ((module) => {

module.exports = require("moment/moment");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9847:
/***/ ((module) => {

module.exports = require("react-icons/ai");

/***/ }),

/***/ 6652:
/***/ ((module) => {

module.exports = require("react-icons/bi");

/***/ }),

/***/ 567:
/***/ ((module) => {

module.exports = require("react-icons/bs");

/***/ }),

/***/ 7865:
/***/ ((module) => {

module.exports = require("react-icons/cg");

/***/ }),

/***/ 6290:
/***/ ((module) => {

module.exports = require("react-icons/fa");

/***/ }),

/***/ 2750:
/***/ ((module) => {

module.exports = require("react-icons/fi");

/***/ }),

/***/ 4751:
/***/ ((module) => {

module.exports = require("react-icons/io");

/***/ }),

/***/ 8098:
/***/ ((module) => {

module.exports = require("react-icons/ri");

/***/ }),

/***/ 5452:
/***/ ((module) => {

module.exports = require("react-icons/rx");

/***/ }),

/***/ 5065:
/***/ ((module) => {

module.exports = require("react-icons/sl");

/***/ }),

/***/ 1946:
/***/ ((module) => {

module.exports = require("react-icons/ti");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6197:
/***/ ((module) => {

module.exports = import("framer-motion");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3598,676,1664,598,9146,3049,5944], () => (__webpack_exec__(2890)));
module.exports = __webpack_exports__;

})();